<?php
// 1. СНАЧАЛА ПОДКЛЮЧАЕМ СИСТЕМУ
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../perms.php';

// 2. ПРЕРЫВАТЕЛЬ ДЛЯ AJAX
if (isset($_GET['search_q']) || isset($_GET['create_new_product'])) {
    $revalFile = __DIR__ . '/../../admin/pages/price_revaluation.php';
    if (file_exists($revalFile)) { require_once $revalFile; }
    exit; 
}

$user = current_user();
$page = $_GET['page'] ?? 'dashboard';
$area = $area ?? 'cabinet'; 

// Логика XP и званий остаётся (без уведомлений)
$uid = $user['id'] ?? null;
$xp_total = 0;
$current_grade = ['title' => 'Стажер', 'icon' => '🐣'];
$xp_percent = 0;
$display_lvl = "1";

if ($uid) {
    // Считаем XP
    try {
        $xp_query = $pdo->prepare("SELECT SUM(amount) FROM user_xp_log WHERE user_id = ?");
        $xp_query->execute([$uid]);
        $xp_total = (int)$xp_query->fetchColumn();
    } catch (Exception $e) {
        $xp_total = 0;
    }

    // Текущее звание
    $stmt = $pdo->prepare("SELECT * FROM user_grades WHERE min_xp <= ? ORDER BY min_xp DESC LIMIT 1");
    $stmt->execute([$xp_total]);
    $current_grade = $stmt->fetch() ?: ['title' => 'Стажер', 'icon' => '🐣', 'min_xp' => 0];

    // Прогресс до следующего уровня
    $next_grade_query = $pdo->prepare("SELECT min_xp FROM user_grades WHERE min_xp > ? ORDER BY min_xp ASC LIMIT 1");
    $next_grade_query->execute([$xp_total]);
    $next_xp_threshold = $next_grade_query->fetchColumn();

    if ($next_xp_threshold) {
        $prev_xp_threshold = (int)$current_grade['min_xp'];
        $xp_percent = (($xp_total - $prev_xp_threshold) / max(1, $next_xp_threshold - $prev_xp_threshold)) * 100;
        $display_lvl = floor($xp_total / 500) + 1;
    } else {
        $xp_percent = 100;
        $display_lvl = "MAX";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>KUB — CRM System</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.js"></script>
<style>
    body, html { margin: 0; padding: 0; height: 100vh; overflow: hidden; font-family: 'Inter', sans-serif; background: #0b0b0f; color: #e8eefc; }
    .wrap { display: flex; height: 100vh; width: 100vw; overflow: hidden; }

    .sidebar { width: 280px; background: #0d0d12; padding: 25px 15px; box-sizing: border-box; border-right: 1px solid rgba(255, 255, 255, 0.05); flex-shrink: 0; display: flex; flex-direction: column; height: 100vh; overflow-y: auto; }
    .sidebar::-webkit-scrollbar { display: none; }

    .brand { font-size: 26px; font-weight: 900; letter-spacing: 5px; margin-bottom: 30px; color: #fff; text-align: center; text-shadow: 0 0 15px rgba(120, 90, 255, 0.4); }

    .userbox { padding: 16px; background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 18px; margin-bottom: 25px; }
    .userbox b { display: block; font-size: 14px; color: #fff; margin-bottom: 4px; }
    .roles-label { font-size: 10px; color: #785aff; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; }

    .item, .item:link, .item:visited { 
        display: flex; align-items: center; padding: 12px 16px; border-radius: 14px; margin-bottom: 4px; 
        font-size: 13px; font-weight: 500;
        color: rgba(255, 255, 255, 0.4) !important;
        transition: 0.2s all; border: 1px solid transparent; text-decoration: none !important; 
    }

    .item:hover { background: rgba(120, 90, 255, 0.05); color: #fff !important; padding-left: 22px; }
    
    .item.active, .item.active:link, .item.active:visited { 
        background: rgba(120, 90, 255, 0.1) !important; 
        color: #b866ff !important; 
        font-weight: 700 !important; 
        border: 1px solid rgba(120, 90, 255, 0.2) !important; 
    }

    .menu-trigger { margin: 20px 0 8px 10px; font-size: 10px; font-weight: 800; color: rgba(255, 255, 255, 0.2); text-transform: uppercase; letter-spacing: 1.5px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; }
    .menu-content { max-height: 0; overflow: hidden; transition: max-height 0.4s ease-out; }
    .menu-content.open { max-height: 1200px; margin-bottom: 15px; }

    .arrow { font-size: 8px; transition: 0.3s; opacity: 0.3; border: 1px solid rgba(255,255,255,0.1); width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; border-radius: 6px; }
    .active-trigger .arrow { transform: rotate(180deg); opacity: 1; color: #785aff; border-color: #785aff; }

    .content { flex: 1; height: 100vh; overflow-y: auto; padding: 40px; box-sizing: border-box; background: #08080c; display: flex; flex-direction: column; align-items: center; }
    .page-container { width: 100%; max-width: 1100px; }
    
    .top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
    .badge { font-size: 10px; font-weight: 900; color: #785aff; text-transform: uppercase; letter-spacing: 1px; }
    .muted { font-size: 12px; opacity: 0.6; }
</style>
</head>
<body>

<div class="wrap">
    <span style="display:none;" data-user-id="<?= (int)($user['id'] ?? 0) ?>"></span>
<aside class="sidebar">
    <div class="brand">KUB</div>
    
    <div class="userbox">
        <b><?= htmlspecialchars(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')) ?></b>
        <div class="roles-label">
            <?php if (!empty($user['id'])): ?>
                <?php
                $stmt = $pdo->prepare("SELECT r.name FROM roles r JOIN user_roles ur ON r.id = ur.role_id WHERE ur.user_id = ?");
                $stmt->execute([$user['id']]);
                $rolesList = $stmt->fetchAll(PDO::FETCH_COLUMN);
                echo htmlspecialchars(implode(' • ', $rolesList ?: ['Сотрудник']));
                ?>
            <?php else: ?>
                Гость
            <?php endif; ?>
        </div>

        <div class="user-rank-box" style="margin-top: 15px; padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.05);">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                <span style="font-size: 20px;"><?= htmlspecialchars($current_grade['icon']) ?></span>
                <div>
                    <div style="font-size: 11px; font-weight: 900; color: #fff; text-transform: uppercase;"><?= htmlspecialchars($current_grade['title']) ?></div>
                    <div style="font-size: 9px; color: #785aff; font-weight: 800;">XP: <?= number_format($xp_total) ?> • LVL <?= $display_lvl ?></div>
                </div>
            </div>
            <div style="height: 4px; background: rgba(255,255,255,0.05); border-radius: 10px; overflow: hidden;">
                <div style="width: <?= min(100, max(0, $xp_percent)) ?>%; height: 100%; background: linear-gradient(90deg, #785aff, #b866ff); box-shadow: 0 0 10px #785aff;"></div>
            </div>
        </div>
    </div>

    <div class="nav">
<?php if ($area === 'cabinet'): ?>
    <h4 class="menu-trigger active-trigger" data-target="cab_main">Кабинет <span class="arrow">▼</span></h4>
    <div class="menu-content open" id="cab_main">
        <a class="item <?= $page==='dashboard'?'active':'' ?>" href="/cabinet/index.php?page=dashboard">🏠 Dashboard</a>
        <a class="item <?= $page==='schedule'?'active':'' ?>" href="/cabinet/index.php?page=schedule">📅 График работы</a>
        <a class="item <?= $page==='checkin'?'active':'' ?>" href="/cabinet/index.php?page=checkin">📍 Check-in</a>
        <a class="item <?= $page==='transfers'?'active':'' ?>" href="/cabinet/index.php?page=transfers">🤝 Передача смен</a>
        <a class="item <?= $page==='sales'?'active':'' ?>" href="/cabinet/index.php?page=sales">💰 Продажи</a>
        <a class="item <?= $page==='sales_history'?'active':'' ?>" href="/cabinet/index.php?page=sales_history">📖 История</a>
        <a class="item <?= $page==='returns'?'active':'' ?>" href="/cabinet/index.php?page=returns" style="border-left: 2px solid #ff6b6b; padding-left: 13px;">🔙 Возвраты</a>
        <a class="item <?= $page==='kpi'?'active':'' ?>" href="/cabinet/index.php?page=kpi">📈 Мой KPI</a>
        <a class="item <?= ($page==='academy' || $page==='academy_lesson_view') ? 'active' : '' ?>" href="/cabinet/index.php?page=academy">🎓 Академия KUB</a>
        <a class="item <?= $page==='clients'?'active':'' ?>" href="/cabinet/index.php?page=clients">👥 База клиентов</a>
        <a class="item <?= $page==='glass'?'active':'' ?>" href="/cabinet/index.php?page=glass">🛡️ Совместимость стекол</a>
        <a class="item <?= $page==='profile'?'active':'' ?>" href="/cabinet/index.php?page=profile">👤 Профиль</a>
    </div>
    
    <?php if (!empty($user['id']) && (has_role('Admin') || has_role('Owner'))): ?>
        <div style="margin-top: 20px; border-top: 1px solid rgba(120, 90, 255, 0.1); padding-top: 10px;">
            <a class="item" href="/admin/index.php?page=dashboard" style="color:#785aff; font-weight:bold;">⚙️ Админ-панель</a>
        </div>
    <?php endif; ?>

<?php else: ?>
    <h4 class="menu-trigger" data-target="adm_mgmt">Управление <span class="arrow">▼</span></h4>
    <div class="menu-content" id="adm_mgmt">
        <a class="item <?= $page==='dashboard'?'active':'' ?>" href="/admin/index.php?page=dashboard">📊 Главная</a>
        <?php if (can_user('contacts')): ?><a class="item <?= $page === 'contacts' ? 'active' : '' ?>" href="/admin/index.php?page=contacts">👥 Список контактов</a><?php endif; ?>
        <?php if (can_user('manage_users')): ?><a class="item <?= ($page==='users' || $page==='user_edit')?'active':'' ?>" href="/admin/index.php?page=users">🛡️ Сотрудники</a><?php endif; ?>
        <?php if (can_user('settings_checkin')): ?><a class="item <?= $page==='settings_checkin'?'active':'' ?>" href="/admin/index.php?page=settings_checkin">🔧 Настройки Check-in</a><?php endif; ?>
        <?php if (can_user('branches')): ?><a class="item <?= $page==='branches'?'active':'' ?>" href="/admin/index.php?page=branches">🏢 Филиалы</a><?php endif; ?>
        <?php if (can_user('users_pending')): ?><a class="item <?= $page==='users_pending'?'active':'' ?>" href="/admin/index.php?page=users_pending">⏳ Заявки</a><?php endif; ?>
        <?php if (can_user('shifts')): ?><a class="item <?= $page==='shifts'?'active':'' ?>" href="/admin/index.php?page=shifts">🗓️ График смен</a><?php endif; ?>
        <?php if (has_role('Admin') || has_role('Owner')): ?>
            <a class="item <?= $page==='report_late'?'active':'' ?>" href="/admin/index.php?page=report_late">⏰ Журнал опозданий</a>
        <?php endif; ?>
        <?php if (can_user('roles')): ?><a class="item <?= $page==='roles'?'active':'' ?>" href="/admin/index.php?page=roles">🔑 Роли и Доступ</a><?php endif; ?>
    </div>
    
    <h4 class="menu-trigger" data-target="adm_academy">🎓 Академия <span class="arrow">▼</span></h4>
    <div class="menu-content" id="adm_academy">
        <a class="item <?= $page==='gamification_hub' ? 'active' : '' ?>" href="/admin/index.php?page=gamification_hub">🎮 Хаб Геймификации</a>
        <a class="item <?= $page==='academy_manage' ? 'active' : '' ?>" href="/admin/index.php?page=academy_manage">📚 Склад тестов</a>
        <a class="item <?= $page==='academy_stats' ? 'active' : '' ?>" href="/admin/index.php?page=academy_stats">📊 Успеваемость</a>
    </div>

    <h4 class="menu-trigger" data-target="adm_clients">👥 База клиентов <span class="arrow">▼</span></h4>
    <div class="menu-content" id="adm_clients">
        <a class="item <?= $page==='clients'?'active':'' ?>" href="/admin/index.php?page=clients">📋 Список клиентов</a>
        <a class="item <?= $page==='client_history'?'active':'' ?>" href="/admin/index.php?page=client_history">📜 История изменений</a>
    </div>

    <h4 class="menu-trigger" data-target="adm_prices">Цены и Переоценка (Сергей Вакаренко)<span class="arrow">▼</span></h4>
    <div class="menu-content" id="adm_prices">
        <?php if (can_user('price_revaluation')): ?><a class="item <?= $page==='price_revaluation'?'active':'' ?>" href="/admin/index.php?page=price_revaluation">🔄 Новая переоценка</a><?php endif; ?>
        <?php if (can_user('price_log')): ?><a class="item <?= $page==='price_log'?'active':'' ?>" href="/admin/index.php?page=price_log">📜 Журнал изменений</a><?php endif; ?>
        <?php if (can_user('price_confirm')): ?><a class="item <?= $page==='price_confirm'?'active':'' ?>" href="/admin/index.php?page=price_confirm">✅ Подтверждение</a><?php endif; ?>
        <?php if (can_user('promotions')): ?><a class="item <?= $page==='promotions'?'active':'' ?>" href="/admin/index.php?page=promotions">🔥 Акции и скидки</a><?php endif; ?>
        <?php if (has_role('Admin') || has_role('Owner')): ?>
        <a class="item <?= $page==='glass'?'active':'' ?>" href="/admin/index.php?page=glass" style="border-top: 1px solid rgba(255,255,255,0.05); padding-top: 10px;">🛡️ Совместимость стекол</a>
    <?php endif; ?>
    </div>

    <h4 class="menu-trigger" data-target="adm_sales">Продажи <span class="arrow">▼</span></h4>
    <div class="menu-content" id="adm_sales">
        <?php if (can_user('sales_all')): ?><a class="item <?= $page==='sales_all'?'active':'' ?>" href="/admin/index.php?page=sales_all">🧾 Все чеки</a><?php endif; ?>
        <?php if (can_user('report_sales')): ?><a class="item <?= $page==='report_sales'?'active':'' ?>" href="/admin/index.php?page=report_sales">📋 Таблица КПЭ</a><?php endif; ?>
        <?php if (can_user('report_sales_checks')): ?><a class="item <?= $page==='report_sales_checks'?'active':'' ?>" href="/admin/index.php?page=report_sales_checks">🔍 Детализация чеков</a><?php endif; ?>
        <?php if (can_user('report_sales_checks') || (int)($_SESSION['user']['id'] ?? 0) === 1): ?>
            <a class="item <?= $page==='returns_control'?'active':'' ?>" href="/admin/index.php?page=returns_control">🔙 Контроль возвратов</a>
        <?php endif; ?>
    </div>

    <h4 class="menu-trigger" data-target="adm_kpi">Система KPI <span class="arrow">▼</span></h4>
    <div class="menu-content" id="adm_kpi">
        <?php if (can_user('kpi')): ?><a class="item <?= $page==='kpi'?'active':'' ?>" href="/admin/index.php?page=kpi">🎯 Аналитика</a><?php endif; ?>
        <?php if (can_user('report_sales_chart')): ?><a class="item <?= $page==='report_sales_chart'?'active':'' ?>" href="/admin/index.php?page=report_sales_chart">📈 График сети</a><?php endif; ?>
        <?php if (can_user('kpi_branch')): ?><a class="item <?= $page==='kpi_branch'?'active':'' ?>" href="/admin/index.php?page=kpi_branch">🏢 По филиалам</a><?php endif; ?>
        <?php if (can_user('kpi_user')): ?><a class="item <?= $page==='kpi_user'?'active':'' ?>" href="/admin/index.php?page=kpi_user">👤 По сотрудникам</a><?php endif; ?>
        <?php if (can_user('kpi_chart')): ?><a class="item <?= $page==='kpi_chart'?'active':'' ?>" href="/admin/index.php?page=kpi_chart">📊 Рейтинг</a><?php endif; ?>
        <?php if (can_user('report_sales_user_chart')): ?><a class="item <?= $page==='report_sales_user_chart'?'active':'' ?>" href="/admin/index.php?page=report_sales_user_chart">📊 Графики продаж</a><?php endif; ?>
    </div>

    <h4 class="menu-trigger" data-target="adm_fin">Финансы и База <span class="arrow">▼</span></h4>
    <div class="menu-content" id="adm_fin">
        <?php if (can_user('kpi_bonus')): ?><a class="item <?= $page==='kpi_bonus'?'active':'' ?>" href="/admin/index.php?page=kpi_bonus">💵 Ведомость (Тек)</a><?php endif; ?>
        <?php if (can_user('kpi_bonuses')): ?><a class="item <?= $page==='kpi_bonuses'?'active':'' ?>" href="/admin/index.php?page=kpi_bonuses">📒 Архив выплат</a><?php endif; ?>
        <?php if (can_user('kpi_plans')): ?><a class="item <?= $page==='kpi_plans'?'active':'' ?>" href="/admin/index.php?page=kpi_plans">🏁 Планы</a><?php endif; ?>
        <?php if (can_user('kpi_fix')): ?><a class="item <?= $page === 'kpi_fix' ? 'active' : '' ?>" href="/admin/index.php?page=kpi_fix">🔒 Фиксация месяца</a><?php endif; ?>
        <?php if (can_user('kpi_settings')): ?><a class="item <?= $page==='kpi_settings'?'active':'' ?>" href="/admin/index.php?page=kpi_settings">⚙️ Параметры KPI</a><?php endif; ?>
        <?php if (can_user('salary_categories')): ?><a class="item <?= $page==='salary_categories'?'active':'' ?>" href="/admin/index.php?page=salary_categories">💳 Категории ЗП</a><?php endif; ?>
        <?php if (can_user('products')): ?><a class="item <?= $page==='products'?'active':'' ?>" href="/admin/index.php?page=products">📦 Товары</a><?php endif; ?>
        <?php if (can_user('import')): ?><a class="item <?= $page==='import'?'active':'' ?>" href="/admin/index.php?page=import">📥 Импорт Excel</a><?php endif; ?>
        
        <?php if (has_role('Admin') || has_role('Owner')): ?>
            <a class="item <?= $page==='staff_monitor'?'active':'' ?>" href="/admin/index.php?page=staff_monitor">🟢 Мониторинг Online</a>
            <a class="item <?= $page==='branch_schedules'?'active':'' ?>" href="/admin/index.php?page=branch_schedules">🕘 Графики работы</a>
        <?php endif; ?>
    </div>
    
    <a class="item" href="/cabinet/index.php?page=dashboard" style="margin-top:25px; opacity:0.8; border: 1px dashed rgba(120,90,255,0.3);">← Вернуться в кабинет</a>
<?php endif; ?>
    </div>

    <a class="item" href="/public/logout.php" style="margin-top:auto; color:#ff6b6b; background: rgba(255, 107, 107, 0.05); border: 1px solid rgba(255, 107, 107, 0.1); border-radius: 14px; padding: 12px 18px;">🚪 Выйти из системы</a>
</aside>

<main class="content">
    <div class="page-container">
        <div class="top">
            <div class="badge"><?= $area === 'admin' ? 'SYSTEM ADMINISTRATION' : 'EMPLOYEE CABINET' ?></div>
            <div class="muted"><?= date('d.m.Y') ?></div>
        </div>

        <!-- Сюда будет подгружаться контент через AJAX -->
        <?php
        // Загрузка основного контента страницы
        $contentFile = match($area) {
            'admin' => __DIR__ . "/../../admin/pages/{$page}.php",
            default => __DIR__ . "/../pages/{$page}.php"
        };

        if (file_exists($contentFile)) {
            include $contentFile;
        } else {
            echo "<p>Страница «{$page}» не найдена.</p>";
        }
        ?>
    </div>
</main>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const contentArea = document.querySelector('.page-container');

    window.loadPage = function(url, pushState = true) {
        const currentPath = window.location.pathname;
        const targetPath = new URL(url, window.location.origin).pathname;
        
        if ((currentPath.includes('/admin/') && targetPath.includes('/cabinet/')) ||
            (currentPath.includes('/cabinet/') && targetPath.includes('/admin/'))) {
            window.location.href = url;
            return;
        }
        
        if (typeof NProgress !== 'undefined') NProgress.start();
        const ajaxUrl = url + (url.includes('?') ? '&' : '?') + 'ajax=1';
        
        fetch(ajaxUrl)
            .then(res => res.text())
            .then(html => {
                contentArea.innerHTML = html;
                const scripts = contentArea.querySelectorAll('script');
                scripts.forEach(oldScript => {
                    const newScript = document.createElement('script');
                    Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
                    newScript.appendChild(document.createTextNode(oldScript.innerHTML));
                    oldScript.parentNode.replaceChild(newScript, oldScript);
                });
                
                if (pushState) history.pushState({ url: url }, '', url);
                updateActiveMenu(url);
                if (typeof NProgress !== 'undefined') NProgress.done();
                document.querySelector('.content').scrollTop = 0;
            })
            .catch(err => {
                window.location.href = url;
            });
    }

    function initPagePlugins(isFirstLoad = false) {
        const triggers = document.querySelectorAll('.menu-trigger');
        triggers.forEach(trigger => {
            const targetId = trigger.getAttribute('data-target');
            const content = document.getElementById(targetId);
            if (!content) return;
            if (isFirstLoad) {
                const isPersistentOpen = localStorage.getItem('menu_open_' + targetId);
                const hasActive = content.querySelector('.active');
                if (hasActive || isPersistentOpen === 'true') {
                    content.classList.add('open');
                    trigger.classList.add('active-trigger');
                }
            }
            trigger.onclick = function() {
                const isOpen = content.classList.toggle('open');
                trigger.classList.toggle('active-trigger');
                localStorage.setItem('menu_open_' + targetId, isOpen);
            };
        });
    }

    function updateActiveMenu(url) {
        document.querySelectorAll('.item').forEach(i => i.classList.remove('active'));
        const currentUrl = new URL(url, window.location.origin);
        const searchPath = currentUrl.pathname + currentUrl.search;
        const activeLink = document.querySelector(`.item[href="${searchPath}"]`) || 
                           document.querySelector(`.item[href="${url}"]`);
        if (activeLink) activeLink.classList.add('active');
    }

    initPagePlugins(true);

    document.addEventListener('click', function(e) {
        const link = e.target.closest('.item');
        if (link && link.href && !link.href.includes('logout.php') && link.target !== '_blank') {
            const url = new URL(link.href);
            if (url.origin === window.location.origin) {
                e.preventDefault();
                loadPage(link.getAttribute('href'));
            }
        }
    });

    window.addEventListener('popstate', (e) => {
        if (e.state && e.state.url) loadPage(e.state.url, false);
    });
});
</script>

</body>
</html>