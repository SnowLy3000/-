<?php
if (!function_exists('h')) { function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } }
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/perms.php';
require_auth();

$user = current_user();
$userId = $user['id'];
$isAdmin = has_role('Admin') || has_role('Owner');
$current_channel = $_GET['channel'] ?? 'general';

$display_name = "Общий чат"; 
$isCreator = false;

// Определяем название чата и проверяем, является ли текущий юзер создателем запроса
if ($current_channel === 'admin') {
    $display_name = "Админ-зона";
} elseif (strpos($current_channel, 'stock_') === 0) {
    $sid = (int)str_replace('stock_', '', $current_channel);
    $st = $pdo->prepare("SELECT product_name, user_id FROM stock_requests WHERE id = ?");
    $st->execute([$sid]);
    $p = $st->fetch();
    if ($p) {
        $display_name = "📦 " . $p['product_name'];
        $isCreator = ($p['user_id'] == $userId);
    } else {
        $display_name = "Запрос товара";
    }
} else {
    $display_name = $current_channel;
}

try {
    // Получаем список каналов с учетом статуса 'active'
    if ($isAdmin) {
        $channels = $pdo->query("SELECT * FROM chat_channels WHERE status = 'active' ORDER BY id DESC LIMIT 30")->fetchAll();
    } else {
        $channels = $pdo->prepare("
            SELECT DISTINCT c.* FROM chat_channels c
            LEFT JOIN stock_requests r ON c.slug = CONCAT('stock_', r.id)
            LEFT JOIN stock_responses res ON r.id = res.request_id
            WHERE (c.slug NOT LIKE 'stock_%' 
               OR r.user_id = ? 
               OR res.user_id = ?)
            AND c.status = 'active'
            ORDER BY c.id DESC
        ");
        $channels->execute([$userId, $userId]);
        $channels = $channels->fetchAll();
    }
} catch(Exception $e) { $channels = []; }
?>

<style>
    .chat-layout { display: flex; height: 85vh; background: #09090b; color: #f4f4f5; font-family: 'Inter', sans-serif; border: 1px solid rgba(255,255,255,0.1); border-radius: 20px; overflow: hidden; }
    .sidebar { width: 280px; background: #0c0c0e; border-right: 1px solid rgba(255,255,255,0.1); display: flex; flex-direction: column; flex-shrink: 0; }
    .sidebar-inner { flex: 1; overflow-y: auto; padding: 20px; }
    .chat-area { flex: 1; display: flex; flex-direction: column; background: #09090b; min-width: 0; position: relative; }
    #stock-alerts-top { flex-shrink: 0; background: rgba(99, 102, 241, 0.05); border-bottom: 1px solid rgba(99, 102, 241, 0.2); display: none; padding: 10px 20px; gap: 10px; overflow-x: auto; }
    .mini-stock-card { background: #18181b; border: 1px solid #6366f1; border-radius: 10px; padding: 10px; min-width: 250px; flex-shrink: 0; }
    .chat-header { height: 60px; border-bottom: 1px solid rgba(255,255,255,0.1); display: flex; align-items: center; padding: 0 20px; flex-shrink: 0; font-weight: bold; justify-content: space-between; }
    .participants-bar { padding: 10px 20px; background: rgba(255,255,255,0.02); border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }
    .p-dot { width: 8px; height: 8px; border-radius: 50%; }
    .p-user { display: flex; align-items: center; gap: 6px; font-size: 11px; font-weight: 700; padding: 4px 8px; background: rgba(255,255,255,0.03); border-radius: 6px; }
    .msg-list { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 12px; }
    .chat-footer { padding: 15px 20px; border-top: 1px solid rgba(255,255,255,0.1); flex-shrink: 0; }
    .nav-link { display: flex; align-items: center; padding: 8px 12px; color: #a1a1aa; text-decoration: none; border-radius: 8px; font-size: 13px; margin-bottom: 2px; }
    .nav-link.active { background: #6366f1; color: #fff; }
    .msg-box { display: flex; gap: 10px; max-width: 85%; }
    .msg-box.mine { align-self: flex-end; flex-direction: row-reverse; }
    .msg-ava { width: 32px!important; height: 32px!important; border-radius: 8px; object-fit: cover; }
    .msg-bubble { padding: 10px 14px; border-radius: 12px; background: #18181b; border: 1px solid rgba(255,255,255,0.05); font-size: 14px; }
    .mine .msg-bubble { background: #6366f1; color: #fff; }
    .t-btn { flex: 1; border: none; padding: 6px; border-radius: 6px; color: #fff; font-size: 10px; font-weight: bold; cursor: pointer; text-decoration: none; text-align: center; display: inline-block; }
    .input-wrap { background: #18181b; border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; display: flex; padding: 5px; }
    #chat-input { flex: 1; background: none; border: none; color: #fff; padding: 8px 12px; outline: none; }
    
    #closed-watermark { pointer-events: none; }
</style>

<div class="chat-layout">
    <div class="sidebar">
        <div class="sidebar-inner">
            <h3 style="font-size: 18px; margin: 0 0 15px 0;">Messenger</h3>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                <span style="font-size:10px; opacity:0.5; font-weight:800; text-transform:uppercase;">Навигация</span>
                <?php if($isAdmin): ?><span onclick="document.getElementById('modalChan').style.display='flex'" style="cursor:pointer; color:#6366f1; font-weight:bold;">+</span><?php endif; ?>
            </div>

            <a href="?page=chat&channel=general" class="nav-link <?= $current_channel==='general'?'active':'' ?>"># Общий канал</a>
            <?php if($isAdmin): ?>
                <a href="?page=chat&channel=admin" class="nav-link <?= $current_channel==='admin'?'active':'' ?>" style="color:#ff6b6b;">🔒 Админ-зона</a>
            <?php endif; ?>

            <div style="font-size:10px; opacity:0.5; font-weight:800; text-transform:uppercase; margin-top:20px; margin-bottom:10px;">Товарные каналы</div>
            <?php foreach($channels as $c): if(strpos($c['slug'], 'stock_') === 0): ?>
                <a href="?page=chat&channel=<?= $c['slug'] ?>" class="nav-link <?= $current_channel===$c['slug']?'active':'' ?>"><?= h($c['name']) ?></a>
            <?php endif; endforeach; ?>

            <div style="margin-top:20px;">
                <button onclick="document.getElementById('modalStock').style.display='flex'" style="width:100%; background:#6366f1; border:none; color:#fff; padding:10px; border-radius:10px; font-weight:bold; cursor:pointer; font-size:12px;">🔍 ЗАПРОСИТЬ НАЛИЧИЕ</button>
            </div>
        </div>
    </div>

    <div class="chat-area">
        <div id="stock-alerts-top"></div>
        <div class="chat-header">
            <span># <?= h($display_name) ?></span>
            <div>
                <?php if (strpos($current_channel, 'stock_') === 0 && ($isCreator || $isAdmin)): ?>
                    <button id="close-btn" onclick="closeCurrentChannel()" style="background: rgba(255,68,68,0.2); border: 1px solid #ff4444; color: #ff4444; padding: 5px 12px; border-radius: 8px; font-size: 11px; cursor: pointer; font-weight: bold; margin-right: 15px; transition: 0.2s;">
                        ЗАКРЫТЬ ЗАПРОС
                    </button>
                <?php endif; ?>
                <span style="font-size:11px; color:#555;">ID: <?= h($userId) ?></span>
            </div>
        </div>

        <?php if (strpos($current_channel, 'stock_') === 0): ?>
            <div id="participants-list" class="participants-bar">
                <div style="font-size: 10px; font-weight: 800; opacity: 0.4; width: 100%; margin-bottom: 5px; text-transform: uppercase;">Сотрудники на смене:</div>
                <div style="font-size:11px; opacity:0.5;">Загрузка статусов...</div>
            </div>
        <?php endif; ?>
        
        <div id="closed-watermark" style="display:none; position:absolute; top:50%; left:50%; transform:translate(-50%, -50%) rotate(-15deg); font-size:60px; font-weight:900; color:rgba(255,68,68,0.15); border:10px solid rgba(255,68,68,0.15); padding:20px; border-radius:20px; pointer-events:none; z-index:10; text-transform:uppercase; letter-spacing:5px;">
            Запрос закрыт
        </div>

        <div id="messages-box" class="msg-list"></div>

        <div class="chat-footer">
            <form id="chat-form" class="input-wrap">
                <input type="text" id="chat-input" placeholder="Введите сообщение..." autocomplete="off">
                <button type="submit" style="background:#6366f1; border:none; color:#fff; padding:0 15px; border-radius:8px; cursor:pointer; font-weight:bold;">Отправить</button>
            </form>
        </div>
    </div>
</div>

<div id="modalStock" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:9999; align-items:center; justify-content:center;">
    <div style="background:#18181b; padding:25px; border-radius:20px; width:340px; border:1px solid #6366f1;">
        <h4 style="margin:0 0 15px 0;">Запрос товара</h4>
        <input type="text" id="p_search" placeholder="Начните вводить..." style="width:100%; padding:12px; background:#000; border:1px solid #333; color:#fff; border-radius:10px; outline:none;">
        <div id="p_results" style="margin-top:10px; max-height:150px; overflow-y:auto; background:#111; border-radius:10px;"></div>
        <button onclick="document.getElementById('modalStock').style.display='none'" style="width:100%; background:none; border:none; color:#555; margin-top:15px; cursor:pointer;">Закрыть</button>
    </div>
</div>

<script>
    window.CHAT_API = '/api/chat_handler.php';
    var chatChannel = '<?= $current_channel ?>';
    var chatUserId = '<?= $userId ?>';
    var lastMsgId = 0; 

    function escapeHtml(t) { const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }

    async function closeCurrentChannel() {
        if (!confirm('Вы уверены, что хотите закрыть этот запрос? Он исчезнет из списка активных.')) return;
        try {
            const res = await fetch(`${window.CHAT_API}?action=close_stock`, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `slug=${chatChannel}`
            });
            const data = await res.json();
            if (data.status === 'ok') {
                if (typeof window.loadPage === 'function') window.loadPage('?page=chat&channel=general');
                else window.location.href = '?page=chat&channel=general';
            } else { alert(data.error || 'Ошибка при закрытии'); }
        } catch (e) { console.error(e); }
    }

    async function loadParticipants() {
        if (!chatChannel || !chatChannel.startsWith('stock_')) return;
        const reqId = chatChannel.replace('stock_', '');
        try {
            const res = await fetch(`${window.CHAT_API}?action=get_participants&request_id=${reqId}&t=${Date.now()}`);
            const data = await res.json();
            const container = document.getElementById('participants-list');
            if (!container) return;
            const participants = Array.isArray(data) ? data : [];
            let html = '<div style="font-size: 10px; font-weight: 800; opacity: 0.4; width: 100%; margin-bottom: 5px; text-transform: uppercase;">Сотрудники на смене:</div>';
            if (participants.length === 0) {
                html += '<div style="font-size:11px; opacity:0.5;">Нет активных сотрудников на смене</div>';
            } else {
                participants.forEach(p => {
                    let color = '#555';
                    if (p.status === 'confirmed') color = '#00c851';
                    if (p.status === 'declined') color = '#ff4444';
                    html += `<div class="p-user" style="color: ${color}; border: 1px solid ${color}44;"><div class="p-dot" style="background: ${color}"></div>${escapeHtml(p.first_name)}</div>`;
                });
            }
            container.innerHTML = html;
        } catch(e) { console.warn("Participants error", e); }
    }

    async function checkChannelStatus() {
        try {
            const res = await fetch(`${window.CHAT_API}?action=get_channel_status&slug=${chatChannel}`);
            const statusData = await res.json();
            if (statusData.status === 'closed') {
                const water = document.getElementById('closed-watermark');
                if (water) water.style.display = 'block';
                const footer = document.querySelector('.chat-footer');
                if (footer) {
                    footer.style.opacity = '0.3';
                    footer.style.pointerEvents = 'none';
                }
                const btn = document.getElementById('close-btn');
                if (btn) btn.remove();
            }
        } catch (e) {}
    }

    async function loadMessages() {
        const res = await fetch(`${window.CHAT_API}?action=load&channel=${chatChannel}&last_id=${lastMsgId}`);
        const data = await res.json();
        if (data.length > 0) {
            const box = document.getElementById('messages-box');
            data.forEach(m => {
                const isM = m.user_id == chatUserId;
                box.insertAdjacentHTML('beforeend', `<div class="msg-box ${isM ? 'mine' : ''}"><img src="${m.avatar_url}" class="msg-ava"><div><div style="font-size:11px; opacity:0.4;"><b>${escapeHtml(m.first_name)}</b> ${m.time}</div><div class="msg-bubble">${escapeHtml(m.message)}</div></div></div>`);
                lastMsgId = m.id;
            });
            box.scrollTop = box.scrollHeight;
        }
        if (chatChannel.startsWith('stock_')) {
            loadParticipants();
            checkChannelStatus();
        }
    }

    async function checkStock() {
        const topBar = document.getElementById('stock-alerts-top');
        if (!topBar) return; 
        try {
            const res = await fetch(`${window.CHAT_API}?action=check_stock`);
            const data = await res.json();
            const others = data.filter(r => r.user_id != chatUserId);
            if (others.length > 0) {
                topBar.style.display = 'flex';
                topBar.innerHTML = others.map(req => `
                    <div class="mini-stock-card" id="mini-req-${req.id}">
                        <div style="font-size:12px; font-weight:bold; margin-bottom:8px;">${escapeHtml(req.owner_name)}: ${escapeHtml(req.product_name)}</div>
                        <div style="display:flex; gap:5px;">
                            <button class="t-btn" style="background:#00c851;" onclick="window.handleGlobalStock(${req.id}, 'confirm')">ЕСТЬ</button>
                            <button class="t-btn" style="background:#ff4444;" onclick="window.handleGlobalStock(${req.id}, 'decline')">НЕТУ</button>
                            <a href="?page=chat&channel=stock_${req.id}" class="t-btn" style="background:#6366f1;">ЧАТ</a>
                        </div>
                    </div>`).join('');
            } else { topBar.style.display = 'none'; }
        } catch (e) {}
    }

    (function initSearch() {
        const input = document.getElementById('p_search');
        if (!input) return;
        input.oninput = async function() {
            const query = this.value.trim();
            if(query.length < 2) return;
            try {
                const res = await fetch(`/cabinet/ajax/search_products.php?q=${encodeURIComponent(query)}`);
                const data = await res.json();
                const resultsBox = document.getElementById('p_results');
                if (data.length > 0) {
                    resultsBox.innerHTML = data.map(i => `<div onclick="sendStock('${escapeHtml(i.name)}')" style="padding:12px; cursor:pointer; border-bottom:1px solid #222; font-size:13px; color:#fff;">${escapeHtml(i.name)}</div>`).join('');
                } else {
                    resultsBox.innerHTML = '<div style="padding:10px; opacity:0.5;">Ничего не найдено</div>';
                }
            } catch (e) { console.error("Search error:", e); }
        };
    })();

    async function sendStock(name) {
        try {
            const targetApi = window.CHAT_API || window.CHAT_API_URL;
            const res = await fetch(`${targetApi}?action=create_stock`, { 
                method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, 
                body:`product=${encodeURIComponent(name)}` 
            });
            const data = await res.json();
            if (data.slug) {
                document.getElementById('modalStock').style.display = 'none';
                if (typeof window.loadPage === 'function') window.loadPage(`?page=chat&channel=${data.slug}`);
                else window.location.href = `?page=chat&channel=${data.slug}`;
            }
        } catch (e) { console.error("Create stock error:", e); }
    }

    document.getElementById('chat-form').onsubmit = async (e) => {
        e.preventDefault();
        const i = document.getElementById('chat-input');
        const v = i.value.trim(); if(!v) return; i.value = '';
        await fetch(`${window.CHAT_API}?action=send`, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`channel=${chatChannel}&message=${encodeURIComponent(v)}` });
        loadMessages();
    };

    loadMessages();
    if (window.chatInterval) clearInterval(window.chatInterval);
    if (window.stockInterval) clearInterval(window.stockInterval);
    window.chatInterval = setInterval(loadMessages, 3000);
    window.stockInterval = setInterval(checkStock, 5000);
</script>