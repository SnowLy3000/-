<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/perms.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user']['id'])) {
    echo json_encode(['error' => 'Unauthorized']); exit;
}

$user = current_user();
$userId = $user['id'];
$isAdmin = has_role('Admin') || has_role('Owner');
$action = $_GET['action'] ?? '';

// --- ЗАГРУЗКА СООБЩЕНИЙ ---
if ($action === 'load') {
    $channel = $_GET['channel'] ?? 'general';
    $lastId = (int)($_GET['last_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT m.*, u.first_name, u.avatar, u.id as user_id FROM chat_messages m JOIN users u ON m.user_id = u.id WHERE m.channel = ? AND m.id > ? ORDER BY m.id ASC");
    $stmt->execute([$channel, $lastId]);
    $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($res as &$m) {
        $m['time'] = date('H:i', strtotime($m['created_at']));
        $m['avatar_url'] = get_user_avatar($m);
    }
    echo json_encode($res);
    exit;
}

// --- ОТПРАВКА СООБЩЕНИЯ ---
if ($action === 'send' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $msg = trim($_POST['message']);
    if (!$msg) exit;
    $pdo->prepare("INSERT INTO chat_messages (channel, user_id, message) VALUES (?, ?, ?)")->execute([$_POST['channel'], $userId, $msg]);
    echo json_encode(['status' => 'ok']);
    exit;
}

// --- УДАЛЕНИЕ СООБЩЕНИЯ ---
if ($action === 'delete_message' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $pdo->prepare("DELETE FROM chat_messages WHERE id = ? AND (user_id = ? OR ?)")->execute([$id, $userId, (int)$isAdmin]);
    echo json_encode(['status' => 'ok']);
    exit;
}

// --- ПОЛУЧЕНИЕ СТАТУСОВ СОТРУДНИКОВ В КАНАЛЕ ---
if ($action === 'get_participants') {
    $requestId = (int)$_GET['request_id'];
    try {
        $stmt = $pdo->prepare("
            SELECT 
                u.id, 
                u.first_name,
                (SELECT COUNT(*) FROM stock_responses WHERE request_id = ? AND user_id = u.id) as confirmed,
                (SELECT COUNT(*) FROM stock_declines WHERE request_id = ? AND user_id = u.id) as declined
            FROM users u
            JOIN shift_sessions ss ON u.id = ss.user_id
            WHERE ss.checkout_at IS NULL
            GROUP BY u.id
        ");
        $stmt->execute([$requestId, $requestId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $result = [];
        foreach ($rows as $row) {
            $status = 'pending';
            if ((int)$row['confirmed'] > 0) $status = 'confirmed';
            else if ((int)$row['declined'] > 0) $status = 'declined';
            $result[] = [
                'id' => (int)$row['id'],
                'first_name' => $row['first_name'],
                'status' => $status
            ];
        }
        echo json_encode($result);
    } catch (Exception $e) { echo json_encode(['error' => $e->getMessage()]); }
    exit;
}

// --- СОЗДАНИЕ КАНАЛА ---
if ($action === 'create_channel' && $isAdmin) {
    $name = trim($_POST['name']);
    $slug = strtolower(preg_replace('/[^A-Za-z0-9-]+/', '_', $name));
    $pdo->prepare("INSERT IGNORE INTO chat_channels (name, slug) VALUES (?, ?)")->execute([$name, $slug]);
    echo json_encode(['status' => 'ok', 'slug' => $slug]);
    exit;
}

// --- ЗАПРОС ТОВАРА + АВТО-КАНАЛ ---
if ($action === 'create_stock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $product = trim($_POST['product']);
    $stmt = $pdo->prepare("INSERT INTO stock_requests (user_id, product_name, expires_at) VALUES (?, ?, NOW() + INTERVAL 1 HOUR)");
    $stmt->execute([$userId, $product]);
    $reqId = $pdo->lastInsertId();
    $slug = "stock_" . $reqId;
    $pdo->prepare("INSERT INTO chat_channels (name, slug) VALUES (?, ?)")->execute(["📦 " . $product, $slug]);
    echo json_encode(['status' => 'ok', 'slug' => $slug]);
    exit;
}

// --- ОТВЕТЫ НА ЗАПРОСЫ (ЕСТЬ / НЕТУ) ---
if ($action === 'confirm_stock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $reqId = (int)$_POST['request_id'];
    $pdo->prepare("INSERT IGNORE INTO stock_responses (request_id, user_id) VALUES (?, ?)")->execute([$reqId, $userId]);
    echo json_encode(['status' => 'ok']);
    exit;
}

if ($action === 'decline_stock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $reqId = (int)$_POST['request_id'];
    $pdo->prepare("INSERT IGNORE INTO stock_declines (request_id, user_id) VALUES (?, ?)")->execute([$reqId, $userId]);
    echo json_encode(['status' => 'ok']);
    exit;
}

// --- ЗАКРЫТИЕ ЗАПРОСА (ВЫНЕСЕНО ИЗ ПРОВЕРКИ) ---
if ($action === 'close_stock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $slug = $_POST['slug']; 
    $requestId = (int)str_replace('stock_', '', $slug);

    $stmt = $pdo->prepare("SELECT user_id FROM stock_requests WHERE id = ?");
    $stmt->execute([$requestId]);
    $creatorId = $stmt->fetchColumn();

    if ($userId == $creatorId || $isAdmin) {
        // 1. Помечаем канал закрытым
        $pdo->prepare("UPDATE chat_channels SET status = 'closed' WHERE slug = ?")->execute([$slug]);
        // 2. Ставим срок запроса на "сейчас", чтобы он пропал из плашек уведомлений
        $pdo->prepare("UPDATE stock_requests SET expires_at = NOW() WHERE id = ?")->execute([$requestId]);
        
        echo json_encode(['status' => 'ok']);
    } else {
        echo json_encode(['error' => 'Нет прав для закрытия']);
    }
    exit;
}

if ($action === 'get_channel_status') {
    $slug = $_GET['slug'];
    $stmt = $pdo->prepare("SELECT status FROM chat_channels WHERE slug = ?");
    $stmt->execute([$slug]);
    $status = $stmt->fetchColumn();
    echo json_encode(['status' => $status]);
    exit;
}

// --- ПРОВЕРКА ЗАПРОСОВ ---
if ($action === 'check_stock') {
    $stmt = $pdo->prepare("
        SELECT r.*, u.first_name as owner_name 
        FROM stock_requests r
        JOIN users u ON r.user_id = u.id
        WHERE r.expires_at > NOW() 
          AND r.id NOT IN (SELECT request_id FROM stock_responses WHERE user_id = ?)
          AND r.id NOT IN (SELECT request_id FROM stock_declines WHERE user_id = ?)
        ORDER BY r.id DESC
    ");
    $stmt->execute([$userId, $userId]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}